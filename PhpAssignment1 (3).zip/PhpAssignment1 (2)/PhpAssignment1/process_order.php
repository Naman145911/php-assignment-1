<?php
//adding the styles
echo "<head>
  <title>Order Confirmation</title>
  <link rel'stylesheet' type='text/css' href='styles.css'>
</head>
<body>
  <h1>Order Confirmation</h1>
  <div class='order-confirmation'>";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $address = $_POST["address"];
  $pizza = $_POST["pizza"];
  $size = $_POST["size"];
//  The implode function in PHP is used to join elements of an array into a string
//    https://www.php.net/manual/en/function.implode.php
  $toppings = isset($_POST["toppings"]) ? implode(", ", $_POST["toppings"]) : "";

  // Create a PDO connection to the database
  $host = '172.31.22.43';
  $dbname = 'Naman200514073';
  $username = 'Naman200514073';
  $password = 'eHc3vApvfw';

  $dsn = "mysql:host=$host;dbname=$dbname";
  $pdo = new PDO($dsn, $username, $password);

  // Prepare and execute the SQL INSERT statement
  $stmt = $pdo->prepare("INSERT INTO orders (name, address, pizza, size, toppings) VALUES (?, ?, ?, ?, ?)");
  $stmt->execute([$name, $address, $pizza, $size, $toppings]);

  // Close the database connection
  $pdo = null;

  echo "<p>Thank you, $name, for your order!</p>";
  echo "<p>Delivery Address: $address</p>";
  echo "<p>Pizza: $pizza</p>";
  echo "<p>Size: $size</p>";
  echo "<p>Toppings: ";
  if (!empty($toppings)) {
    echo $toppings;
  } else {
    echo "No toppings selected";
  }
    echo "</p>";
    echo "</class>";
    echo "</body>";
}